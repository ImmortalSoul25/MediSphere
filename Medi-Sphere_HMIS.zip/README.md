# MediSphere (Maternal Care Portal)

**Repository Link:** [https://github.com/ImmortalSoul25/MediSphere](https://github.com/ImmortalSoul25/MediSphere)

MediSphere is a comprehensive, full-stack maternal healthcare management portal. It enables clinics to manage patient records, track medical histories, automate appointments, manage daily queues, and seamlessly communicate with patients via a WhatsApp Bot integration.

---

## 🛠️ Architecture & Tech Stack

This project is structured as a **monorepo**, containing both the frontend and backend in the same repository.

*   **Frontend:** React (Vite), Tailwind CSS, Lucide React (Icons), date-fns (Time formatting).
*   **Backend:** Python 3, FastAPI, Uvicorn.
*   **Database:** MongoDB Atlas (accessed asynchronously via Motor).
*   **Messaging:** WhatsApp Cloud API Webhook Integration.
*   **Hosting:**
    *   **Frontend:** Vercel (`https://medi-sphere-lenest.vercel.app`)
    *   **Backend:** Render (`https://medisphere-pxwm.onrender.com`)

---

## ✨ Core Features

1.  **Patient Management:** Add, edit, and view patient profiles, comprehensive medical histories, and track current conditions (e.g., Pregnancy, PCOS).
2.  **Daily Queue System:** A live Kanban-style drag-and-drop queue for the reception to track patients who are "Waiting" vs. "Completed" on a given day.
3.  **Appointment Scheduling:** A unified calendar to schedule follow-ups, edit appointments, and view pending requests from patients.
4.  **WhatsApp Integration:** Patients can request appointments via a WhatsApp bot. The bot routes requests directly into the portal's "Pending Requests" table for the receptionist to approve/reject, triggering automated WhatsApp replies.
5.  **Analytics Dashboard:** Visual representation of patient demographics, appointment trends, and condition distributions.
6.  **Configuration & Backup:** A dynamic settings page to configure conditions, customize WhatsApp templates, and backup/restore the entire database via ZIP files.

---

## 🚀 Deployment Guide (Crucial for Upgrades)

### 1. Frontend Proxying (`vercel.json` and `vite.config.js`)
Because the frontend and backend are hosted on different domains, we avoid CORS issues by proxying API requests through the frontend domain.
*   **Locally:** `vite.config.js` proxies `/patient`, `/queue-api`, etc., to `http://localhost:8000`.
*   **Production:** `vercel.json` strictly maps all API paths to the Render backend domain using Vercel Rewrites.
    *   *Upgrade Note:* If you add a new API router in the backend (e.g., `/inventory`), you **MUST** add a rewrite rule for it in `vercel.json` or the deployed frontend will throw a `404 Not Found`.

### 2. Timezone Handling (Very Important)
The Render server runs in **UTC**, while the frontend runs in the local timezone (IST).
To prevent issues where wait times show as "Just now" or negative differences, the backend explicitly uses **timezone-aware UTC timestamps**:
```python
from datetime import datetime, timezone
# Always use this for storing dates in MongoDB:
timestamp = datetime.now(timezone.utc).isoformat()
```
The browser will automatically parse this UTC timestamp into the user's correct local time.

---

## 💻 Local Development Setup

### Prerequisites
*   Node.js (v18+)
*   Python 3.10+
*   MongoDB Atlas URI

### 1. Setup Backend
1.  Navigate to the root directory.
2.  Create a virtual environment: `python -m venv venv`
3.  Activate it: `venv\Scripts\activate` (Windows) or `source venv/bin/activate` (Mac/Linux)
4.  Install requirements (if `requirements.txt` exists) or install manually: `pip install fastapi uvicorn motor python-dotenv certifi`
5.  Create a file named `atlas-credentials.env` in the root folder and add your connection string:
    ```env
    MONGODB_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/?retryWrites=true&w=majority
    ```
6.  Start the FastAPI server:
    ```bash
    uvicorn main:app --reload
    ```
    The backend will run on `http://localhost:8000`.

### 2. Setup Frontend
1.  Open a new terminal in the root directory.
2.  Install dependencies:
    ```bash
    npm install
    ```
3.  Start the Vite development server:
    ```bash
    npm run dev
    ```
    The frontend will run on `http://localhost:5173`.

---

## 🏗️ Codebase Structure for Future Developers

### Backend (`/routers` and `main.py`)
The backend is highly modular. `main.py` is the entry point, but business logic is separated into specific routers inside the `/routers` folder:
*   `patients.py`: CRUD for patients.
*   `appointments.py`: Handing appointment requests and past appointments.
*   `calendar.py`: Managing calendar events and scheduled appointments.
*   `queue.py`: Managing the live waiting room queue.
*   `whatsapp.py`: Webhook endpoints for the WhatsApp bot.
*   `settings.py`: Portal configuration, templates, and database backup logic.

*To add a new feature:*
1. Create a new file in `/routers` (e.g., `billing.py`).
2. Add your `@router.get(...)` endpoints.
3. Import and include the router in `main.py`: `app.include_router(billing.router)`.
4. Add the route proxy to `vercel.json` and `vite.config.js`.

### Frontend (`/src`)
*   **`/components`**: Reusable UI components (Sidebar, Topbar, Modals).
*   **`/context`**: React Contexts for global state management. `DataContext.jsx` is the primary state manager holding patients, appointments, and configuration.
*   **`/pages`**: Individual dashboard views (Dashboard, Patients, Calendar, Queue, Settings).

*To add a new page:*
1. Create the component in `/src/pages`.
2. Add the route in `/src/App.jsx`.
3. Add the navigation link in `/src/components/Sidebar.jsx`.

### Database (`database.py`)
All MongoDB collections are initialized and exported from `database.py`. If you need a new table/collection, declare it here first:
```python
new_collection = db["new_collection_name"]
```
Then import it into your router files to perform queries.

---

## 🛡️ License & Maintenance
Developed for Maternal Care Project. When pushing updates, ensure that the WhatsApp webhook URL in the Meta Developer Console points to the correct Render URL if changes are made to the `/whatsapp` endpoint.
